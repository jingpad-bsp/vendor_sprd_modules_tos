#ifndef JPEG_SETJMP_H
#define JPEG_SETJMP_H

#define _JBFP 1
#define _JBMOV 60
#define _JBOFF 4
#define _NSETJMP 17

typedef int jpeg_jmp_buff[_NSETJMP];

unsigned long jpeg_getfp(void);
int jpeg_setjmp(jpeg_jmp_buff env);
void jpeg_setfp(int fp);
int jpeg_dojmp(jpeg_jmp_buff env);
void jpeg_longjmp(jpeg_jmp_buff env,int val);
char *jpeg_stackptr(void);

#endif