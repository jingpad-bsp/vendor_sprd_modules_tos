/* Copyright 2014 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Common definition for WOFF2 encoding/decoding */

#ifndef WOFF2_WOFF2_COMMON_H_
#define WOFF2_WOFF2_COMMON_H_

#include <stddef.h>
#include <inttypes.h>
#include <woff2/map_list.h>

static const uint32_t kWoff2Signature = 0x774f4632;  // "wOF2"

#define MAX_COMMPRESS_DATA_SIZE (2 * 1024 * 1024)

typedef enum {
	NO_MEM_ERR = 1,
	LOCA_MEM_ERR,
	GLYF_FILE_MEM_ERR,
	HMTX_BUFF_MEM_ERR,
	ADV_WIDTH_MEM_ERR,
	LSBS_WIDTH_MEM_ERR,
	HMTX_TABLE_MEM_ERR,
	OUTPUT_MEM_ERR,
	FONT_INFOS_MEM_ERR,
	FINALSIZE_FILE_MEM_ERR,
	MEMORYOUT_MEM_ERR,
	UNCOMPRESSED_BUF_MEM_ERR,
	READHEADER_FILE_MEM_ERR,
	HDR_TABLES_MEM_ERR,
	SUBSTREAMS_MEM_ERR,
	SUBSTREAM_BUFFER_MEM_ERR,
	X_MINS_MEM_ERR,
	
}WOFF2_MEMORY_ERROR_MSG;

typedef struct Point {
  int x;
  int y;
  int on_curve;
}Point;

// Table message
typedef struct Table {
  uint32_t tag;
  uint32_t flags;
  uint32_t src_offset;
  uint32_t src_length;
  uint32_t transform_length;
  uint32_t dst_offset;
  uint32_t dst_length;
//  const uint8_t* dst_data;
}Table;

// Compute checksum over size bytes of buf
uint32_t ComputeULongSum(const uint8_t* buf, size_t size);
int Commonabs(int number);
int CommonMax(int a, int b);
int CommonMin(int a, int b);
uint32_t Round4(uint32_t value);

#endif  // WOFF2_WOFF2_COMMON_H_
