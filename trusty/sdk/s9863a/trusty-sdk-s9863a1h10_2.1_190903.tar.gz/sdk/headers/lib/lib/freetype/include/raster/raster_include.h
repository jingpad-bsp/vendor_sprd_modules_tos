#define RASTER_ERRS_H      <raster/rasterrs.h>
#define TRUETYPE_REND1_H   <raster/ftrend1.h>
#define TRUETYPE_RASTER_H  <raster/ftraster.h>
#define TRUETYPE_MISC_H    <raster/ftmisc.h>
#define FREETYPE_IMAGE_H   <raster/ftimage.h>