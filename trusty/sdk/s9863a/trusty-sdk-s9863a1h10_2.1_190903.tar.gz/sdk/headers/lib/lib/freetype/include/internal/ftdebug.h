/***************************************************************************/
/*                                                                         */
/*  ftdebug.h                                                              */
/*                                                                         */
/*    Debugging and logging component (specification).                     */
/*                                                                         */
/*  Copyright 1996-2002, 2004, 2006-2009, 2013 by                          */
/*  David Turner, Robert Wilhelm, and Werner Lemberg.                      */
/*                                                                         */
/*  This file is part of the FreeType project, and may only be used,       */
/*  modified, and distributed under the terms of the FreeType project      */
/*  license, LICENSE.TXT.  By continuing to use, modify, or distribute     */
/*  this file you indicate that you have read the license and              */
/*  understand and accept it fully.                                        */
/*                                                                         */
/*                                                                         */
/*  IMPORTANT: A description of FreeType's debugging support can be        */
/*             found in `docs/DEBUG.TXT'.  Read it if you need to use or   */
/*             understand this code.                                       */
/*                                                                         */
/***************************************************************************/


#ifndef __FTDEBUG_H__
#define __FTDEBUG_H__


#include <ft2build.h>
#include FT_CONFIG_CONFIG_H
#include FT_FREETYPE_H


FT_BEGIN_HEADER


/*************************************************************************/
/*                                                                       */
/* Define the FT_TRACE macro                                             */
/*                                                                       */
/* IMPORTANT!                                                            */
/*                                                                       */
/* Each component must define the macro FT_COMPONENT to a valid FT_Trace */
/* value before using any TRACE macro.                                   */
/*                                                                       */
/*************************************************************************/

#define FT_TRACE( level, varformat )  do { } while ( 0 )      /* nothing */

/*************************************************************************/
/*                                                                       */
/* <Function>                                                            */
/*    FT_Trace_Get_Count                                                 */
/*                                                                       */
/* <Description>                                                         */
/*    Return the number of available trace components.                   */
/*                                                                       */
/* <Return>                                                              */
/*    The number of trace components.  0 if FreeType 2 is not built with */
/*    FT_DEBUG_LEVEL_TRACE definition.                                   */
/*                                                                       */
/* <Note>                                                                */
/*    This function may be useful if you want to access elements of      */
/*    the internal `ft_trace_levels' array by an index.                  */
/*                                                                       */
FT_BASE(FT_Int)
FT_Trace_Get_Count(void);


/*************************************************************************/
/*                                                                       */
/* <Function>                                                            */
/*    FT_Trace_Get_Name                                                  */
/*                                                                       */
/* <Description>                                                         */
/*    Return the name of a trace component.                              */
/*                                                                       */
/* <Input>                                                               */
/*    The index of the trace component.                                  */
/*                                                                       */
/* <Return>                                                              */
/*    The name of the trace component.  This is a statically allocated   */
/*    C string, so do not free it after use.  NULL if FreeType 2 is not  */
/*    built with FT_DEBUG_LEVEL_TRACE definition.                        */
/*                                                                       */
/* <Note>                                                                */
/*    Use @FT_Trace_Get_Count to get the number of available trace       */
/*    components.                                                        */
/*                                                                       */
/*    This function may be useful if you want to control FreeType 2's    */
/*    debug level in your application.                                   */
/*                                                                       */
FT_BASE(const char *)
FT_Trace_Get_Name(FT_Int  idx);


/*************************************************************************/
/*                                                                       */
/* You need two opening and closing parentheses!                         */
/*                                                                       */
/* Example: FT_TRACE0(( "Value is %i", foo ))                            */
/*                                                                       */
/* Output of the FT_TRACEX macros is sent to stderr.                     */
/*                                                                       */
/*************************************************************************/

#define FT_TRACE0( varformat )  FT_TRACE( 0, varformat )
#define FT_TRACE1( varformat )  FT_TRACE( 1, varformat )
#define FT_TRACE2( varformat )  FT_TRACE( 2, varformat )
#define FT_TRACE3( varformat )  FT_TRACE( 3, varformat )
#define FT_TRACE4( varformat )  FT_TRACE( 4, varformat )
#define FT_TRACE5( varformat )  FT_TRACE( 5, varformat )
#define FT_TRACE6( varformat )  FT_TRACE( 6, varformat )
#define FT_TRACE7( varformat )  FT_TRACE( 7, varformat )


/*************************************************************************/
/*                                                                       */
/* Define the FT_ERROR macro.                                            */
/*                                                                       */
/* Output of this macro is sent to stderr.                               */
/*                                                                       */
/*************************************************************************/

#define FT_ERROR( varformat )  do { } while ( 0 )      /* nothing */

/*************************************************************************/
/*                                                                       */
/* Define the FT_ASSERT and FT_THROW macros.  The call to `FT_Throw'     */
/* makes it possible to easily set a breakpoint at this function.        */
/*                                                                       */
/*************************************************************************/

#define FT_ASSERT( condition )  do { } while ( 0 )

#define FT_THROW( e )  FT_ERR_CAT( FT_ERR_PREFIX, e )

/*************************************************************************/
/*                                                                       */
/* Define `FT_Message' and `FT_Panic' when needed.                       */
/*                                                                       */
/*************************************************************************/

FT_BASE(void)
ft_debug_init(void);

FT_END_HEADER

#endif /* __FTDEBUG_H__ */


/* END */
