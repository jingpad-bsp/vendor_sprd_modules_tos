/***************************************************************************/
/*                                                                         */
/*  ftoption.h (for development)                                           */
/*                                                                         */
/*    User-selectable configuration macros (specification only).           */
/*                                                                         */
/*  Copyright 1996-2014 by                                                 */
/*  David Turner, Robert Wilhelm, and Werner Lemberg.                      */
/*                                                                         */
/*  This file is part of the FreeType project, and may only be used,       */
/*  modified, and distributed under the terms of the FreeType project      */
/*  license, LICENSE.TXT.  By continuing to use, modify, or distribute     */
/*  this file you indicate that you have read the license and              */
/*  understand and accept it fully.                                        */
/*                                                                         */
/***************************************************************************/


#ifndef __FTOPTION_H__
#define __FTOPTION_H__


#include <ft2build.h>


FT_BEGIN_HEADER


/*************************************************************************/
/*************************************************************************/
/****                                                                 ****/
/**** G E N E R A L   F R E E T Y P E   2   C O N F I G U R A T I O N ****/
/****                                                                 ****/
/*************************************************************************/
/*************************************************************************/


/*************************************************************************/
/*                                                                       */
/* The size in bytes of the render pool used by the scan-line converter  */
/* to do all of its work.                                                */
/*                                                                       */
/* This must be greater than 4KByte if you use FreeType to rasterize     */
/* glyphs; otherwise, you may set it to zero to avoid unnecessary        */
/* allocation of the render pool.                                        */
/*                                                                       */
#define FT_RENDER_POOL_SIZE  16384L


/*************************************************************************/
/*                                                                       */
/* FT_MAX_MODULES                                                        */
/*                                                                       */
/*   The maximum number of modules that can be registered in a single    */
/*   FreeType library object.  32 is the default.                        */
/*                                                                       */
#define FT_MAX_MODULES  32


/*************************************************************************/
/*                                                                       */
/* Define to disable the use of file stream functions and types, FILE,   */
/* fopen() etc.  Enables the use of smaller system libraries on embedded */
/* systems that have multiple system libraries, some with or without     */
/* file stream support, in the cases where file stream support is not    */
/* necessary such as memory loading of font files.                       */
/*                                                                       */
#define FT_CONFIG_OPTION_DISABLE_STREAM_SUPPORT

#define TT_CONFIG_CMAP_FORMAT_4




FT_END_HEADER


#endif /* __FTOPTION_H__ */


/* END */