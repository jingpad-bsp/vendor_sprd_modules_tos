/*
* Copyright (c) 2016, Spreadtrum Communications.
*
* The above copyright notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef _SPRD_PAL_CHIPONE_H_
#define _SPRD_PAL_CHIPONE_H_

#include <arch/uthread.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define SENSOR_VERSION_MAX_LENGTH   64
#define SENSOR_NAME_MAX_LENGTH      64

enum fp_default_cmd_info{
  SPI_WRITE_AND_READ = 0,
  IFAA_SET_LAST_IDENTIFIED = 1,
  IFAA_GET_LAST_IDENTIFIED = 2,
  IFAA_SET_FP_ENROLLED_ID_LIST = 3,
  IFAA_GET_FP_ENROLLED_ID_LIST = 4,
  SOTER_SET_FP_INFO = 5,
  SOTER_GET_FP_INFO = 6,
  IFAA_SET_FP_VENDOR_ID = 7,
  IFAA_GET_FP_VENDOR_ID = 8,
  CMD_MAX
};

struct WRITE_THEN_READ_STR{
	uint32_t	max_speed_hz;
	uint8_t		chip_select;
	uint8_t		mode;
	uint8_t		bits_per_word;
	uint8_t		number;
	user_addr_t	rxbuf;
	user_addr_t	txbuf;
	uint32_t	len;
	uint8_t		debug;
};

typedef struct {
    uint32_t list_num;
    uint8_t* fps;
}IFAA_LIST_INFO;

typedef struct soter_fp_info {
    uint32_t fid;
    unsigned char sensor_version[SENSOR_VERSION_MAX_LENGTH + 1];
    unsigned char sensor_name[SENSOR_NAME_MAX_LENGTH + 1];
} soter_fp_info_t;

extern const int spi_bus_num_max;

#ifdef __cplusplus
}
#endif

#endif
