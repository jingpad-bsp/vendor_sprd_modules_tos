/*
 * Copyright (c) 2008-2014 Travis Geiselbrecht
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#pragma once

#ifndef ASSEMBLY

#include <stdbool.h>
#include <compiler.h>
#include <reg.h>
#include <arch/arm64.h>

#define USE_GCC_ATOMICS 1
#define ENABLE_CYCLE_COUNTER 1

#ifdef WITH_JAVELIN
#define MPIDR_AFFLVL_MASK	0xff
#define MPIDR_AFF1_SHIFT	8
#define MPIDR_AFF2_SHIFT	16
#define MPIDR_MT_BITMASK	(0x1 << 24)
#define MPIDR_AFFLVL0_MASK MPIDR_AFFLVL_MASK
#define MPIDR_AFFLVL1_MASK (MPIDR_AFFLVL_MASK << MPIDR_AFF1_SHIFT)
#define MPIDR_AFFLVL2_MASK (MPIDR_AFFLVL_MASK << MPIDR_AFF2_SHIFT)
#endif

#ifdef CONFIG_SPRD_GICV3
// override of some routines
static inline void arch_enable_ints(void)
{
    CF;
    __asm__ volatile("msr daifclr, #3" ::: "memory");
}

static inline void arch_disable_ints(void)
{
    __asm__ volatile("msr daifset, #3" ::: "memory");
    CF;
}

static inline bool arch_ints_disabled(void)
{
    unsigned int state;

    __asm__ volatile("mrs %0, daif" : "=r"(state));
    state &= (3<<6);

    return state == (unsigned int)0xC0 ? 1 : 0;
}

static inline void arch_enable_irqs(void)
{
    CF;
    __asm__ volatile("msr daifclr, #2" ::: "memory");
}

static inline void arch_disable_irqs(void)
{
    __asm__ volatile("msr daifset, #2" ::: "memory");
    CF;
}

static inline bool arch_irqs_disabled(void)
{
    unsigned int state;

    __asm__ volatile("mrs %0, daif" : "=r"(state));
    state &= (1<<7);

    return !!state;
}

static inline void arch_enable_fiqs(void)
{
    CF;
    __asm__ volatile("msr daifclr, #1" ::: "memory");
}

static inline void arch_disable_fiqs(void)
{
    __asm__ volatile("msr daifset, #1" ::: "memory");
    CF;
}

static inline bool arch_fiqs_disabled(void)
{
    unsigned int state;

    __asm__ volatile("mrs %0, daif" : "=r"(state));
    state &= (1<<6);

    return !!state;
}
#else
// override of some routines
static inline void arch_enable_ints(void)
{
    CF;
    __asm__ volatile("msr daifclr, #2" ::: "memory");
}

static inline void arch_disable_ints(void)
{
    __asm__ volatile("msr daifset, #2" ::: "memory");
    CF;
}

static inline bool arch_ints_disabled(void)
{
    unsigned int state;

    __asm__ volatile("mrs %0, daif" : "=r"(state));
    state &= (1<<7);

    return !!state;
}

static inline void arch_enable_fiqs(void)
{
    CF;
    __asm__ volatile("msr daifclr, #1" ::: "memory");
}

static inline void arch_disable_fiqs(void)
{
    __asm__ volatile("msr daifset, #1" ::: "memory");
    CF;
}

static inline bool arch_fiqs_disabled(void)
{
    unsigned int state;

    __asm__ volatile("mrs %0, daif" : "=r"(state));
    state &= (1<<6);

    return !!state;
}
#endif

#define mb()        __asm__ volatile("dsb sy" : : : "memory")
#define rmb()       __asm__ volatile("dsb ld" : : : "memory")
#define wmb()       __asm__ volatile("dsb st" : : : "memory")

#ifdef WITH_SMP
#define smp_mb()    __asm__ volatile("dmb ish" : : : "memory")
#define smp_rmb()   __asm__ volatile("dmb ishld" : : : "memory")
#define smp_wmb()   __asm__ volatile("dmb ishst" : : : "memory")
#else
#define smp_mb()    CF
#define smp_wmb()   CF
#define smp_rmb()   CF
#endif

static inline int atomic_add(volatile int *ptr, int val)
{
#if USE_GCC_ATOMICS
    return __atomic_fetch_add(ptr, val, __ATOMIC_RELAXED);
#else
    int old;
    int temp;
    int test;

    do {
        __asm__ volatile(
            "ldrex  %[old], [%[ptr]]\n"
            "adds   %[temp], %[old], %[val]\n"
            "strex  %[test], %[temp], [%[ptr]]\n"
            : [old]"=&r" (old), [temp]"=&r" (temp), [test]"=&r" (test)
            : [ptr]"r" (ptr), [val]"r" (val)
            : "memory", "cc");

    } while (test != 0);

    return old;
#endif
}

static inline int atomic_or(volatile int *ptr, int val)
{
#if USE_GCC_ATOMICS
    return __atomic_fetch_or(ptr, val, __ATOMIC_RELAXED);
#else
    int old;
    int temp;
    int test;

    do {
        __asm__ volatile(
            "ldrex  %[old], [%[ptr]]\n"
            "orrs   %[temp], %[old], %[val]\n"
            "strex  %[test], %[temp], [%[ptr]]\n"
            : [old]"=&r" (old), [temp]"=&r" (temp), [test]"=&r" (test)
            : [ptr]"r" (ptr), [val]"r" (val)
            : "memory", "cc");

    } while (test != 0);

    return old;
#endif
}

static inline int atomic_and(volatile int *ptr, int val)
{
#if USE_GCC_ATOMICS
    return __atomic_fetch_and(ptr, val, __ATOMIC_RELAXED);
#else
    int old;
    int temp;
    int test;

    do {
        __asm__ volatile(
            "ldrex  %[old], [%[ptr]]\n"
            "ands   %[temp], %[old], %[val]\n"
            "strex  %[test], %[temp], [%[ptr]]\n"
            : [old]"=&r" (old), [temp]"=&r" (temp), [test]"=&r" (test)
            : [ptr]"r" (ptr), [val]"r" (val)
            : "memory", "cc");

    } while (test != 0);

    return old;
#endif
}

static inline int atomic_swap(volatile int *ptr, int val)
{
#if USE_GCC_ATOMICS
    return __atomic_exchange_n(ptr, val, __ATOMIC_RELAXED);
#else
    int old;
    int test;

    do {
        __asm__ volatile(
            "ldrex  %[old], [%[ptr]]\n"
            "strex  %[test], %[val], [%[ptr]]\n"
            : [old]"=&r" (old), [test]"=&r" (test)
            : [ptr]"r" (ptr), [val]"r" (val)
            : "memory");

    } while (test != 0);

    return old;
#endif
}

static inline int atomic_cmpxchg(volatile int *ptr, int oldval, int newval)
{
#if USE_GCC_ATOMICS
    __atomic_compare_exchange_n(ptr, &oldval, newval, false,
                                __ATOMIC_RELAXED, __ATOMIC_RELAXED);
    return oldval;
#else
    int old;
    int test;

    do {
        __asm__ volatile(
            "ldrex  %[old], [%[ptr]]\n"
            "mov    %[test], #0\n"
            "teq    %[old], %[oldval]\n"
#if ARM_ISA_ARMV7M
            "bne    0f\n"
            "strex  %[test], %[newval], [%[ptr]]\n"
            "0:\n"
#else
            "strexeq %[test], %[newval], [%[ptr]]\n"
#endif
            : [old]"=&r" (old), [test]"=&r" (test)
            : [ptr]"r" (ptr), [oldval]"Ir" (oldval), [newval]"r" (newval)
            : "cc");

    } while (test != 0);

    return old;
#endif
}

static inline uint32_t arch_cycle_count(void)
{
#if ARM_ISA_ARM7M
#if ENABLE_CYCLE_COUNTER
#define DWT_CYCCNT (0xE0001004)
    return *REG32(DWT_CYCCNT);
#else
    return 0;
#endif
#elif ARM_ISA_ARMV7
    uint32_t count;
    __asm__ volatile("mrc       p15, 0, %0, c9, c13, 0"
        : "=r" (count)
        );
    return count;
#else
//#warning no arch_cycle_count implementation
    return 0;
#endif
}

/* use the cpu local thread context pointer to store current_thread */
static inline struct thread *get_current_thread(void)
{
    return (struct thread *)ARM64_READ_SYSREG(tpidr_el1);
}

static inline void set_current_thread(struct thread *t)
{
    ARM64_WRITE_SYSREG(tpidr_el1, (uint64_t)t);
}

static inline uint arch_curr_cpu_num(void)
{
    uint64_t mpidr =  ARM64_READ_SYSREG(mpidr_el1);
#ifdef WITH_JAVELIN
   /* uint64_t mpidr_afflvl0;
    uint64_t mpidr_afflvl1;
    uint64_t mpidr_afflvl2;

    mpidr &= 0x7fffffff;

    if (mpidr & MPIDR_MT_BITMASK) {
	mpidr_afflvl0 = ((mpidr & MPIDR_AFFLVL0_MASK) & 0x0f) << 0x01;
	mpidr_afflvl1 = (mpidr & MPIDR_AFFLVL1_MASK) >> 0x8 ;
	mpidr_afflvl2 = (mpidr & MPIDR_AFFLVL2_MASK) >> 0x8;
	mpidr = mpidr_afflvl2 | mpidr_afflvl1 | mpidr_afflvl0;
    }*/
	switch (mpidr) {
		case 0x81010000:
			return 2;

		case 0x81010001:
			return 3;

		case 0x81010100:
			return 4;

		case 0x81010101:
			return 5;

		default:
			break;
	}
#endif
#if WITH_SMP
    if (mpidr & MPIDR_MT_BITMASK)
        mpidr = mpidr >> MPIDR_AFF1_SHIFT;
    return ((mpidr & ((1U << SMP_CPU_ID_BITS) - 1)) >> 8 << SMP_CPU_CLUSTER_SHIFT) | (mpidr & 0xff);
#else
    return 0;
#endif
}

#define WITH_CRASH_REGISTERS_DUMP 1

static inline void crash_setup_regs(struct arm64_iframe_long *iframe)
{
    uint64_t tmp1, tmp2;

    asm volatile (
        "stp	 x0,   x1, [%2, #16 *  0]\n"
        "stp	 x2,   x3, [%2, #16 *  1]\n"
        "stp	 x4,   x5, [%2, #16 *  2]\n"
        "stp	 x6,   x7, [%2, #16 *  3]\n"
        "stp	 x8,   x9, [%2, #16 *  4]\n"
        "stp	x10,  x11, [%2, #16 *  5]\n"
        "stp	x12,  x13, [%2, #16 *  6]\n"
        "stp	x14,  x15, [%2, #16 *  7]\n"
        "stp	x16,  x17, [%2, #16 *  8]\n"
        "stp	x18,  x19, [%2, #16 *  9]\n"
        "stp	x20,  x21, [%2, #16 * 10]\n"
        "stp	x22,  x23, [%2, #16 * 11]\n"
        "stp	x24,  x25, [%2, #16 * 12]\n"
        "stp	x26,  x27, [%2, #16 * 13]\n"
        "stp	x28,  x29, [%2, #16 * 14]\n"
        "mov	 %0,  sp\n"
        "stp	x30,  %0,  [%2, #16 * 15]\n"
        /* save PSTATE as SPSR */
        "mrs	 %0, CurrentEL\n"
        "mrs	 %1, SPSEL\n"
        "orr	 %0, %0, %1\n"
        "mrs	 %1, DAIF\n"
        "orr	 %0, %0, %1\n"
        "mrs	 %1, NZCV\n"
        "orr	 %0, %0, %1\n"
        /* Save PC as ELR  */
        "adr	 %1, 1f\n"
    "1:\n"
        "stp	 %1, %0,   [%2, #16 * 16]\n"
        : "=&r" (tmp1), "=&r" (tmp2)
        : "r" (iframe)
        : "memory"
        );
}

void dump_iframe(const struct arm64_iframe_long *iframe);

static inline void crash_dump_regs(void)
{
    struct arm64_iframe_long regs = {{0}, 0, 0};

    crash_setup_regs(&regs);

    dump_iframe(&regs);
}

#endif // ASSEMBLY

