#if !defined(__ALLOCA_H)
#define __ALLOCA_H

#define alloca(size) __builtin_alloca (size)

#endif  /* !__ALLOCA_H */
