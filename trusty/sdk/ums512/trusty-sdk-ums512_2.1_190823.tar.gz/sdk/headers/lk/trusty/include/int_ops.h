/*
* Copyright (c) 2016, Spreadtrum Communications.
*
* The above copyright notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef __OPS_H
#define __OPS_H

#include <arch/arch_ops.h>

static inline void enable_all_ints(void)
{
#ifdef CONFIG_SPRD_GICV3
	arch_enable_ints();
#else
	arch_enable_fiqs();
	arch_enable_ints();
#endif
}

static inline void disable_all_ints(void)
{
#ifdef CONFIG_SPRD_GICV3
	arch_disable_ints();
#else
	arch_disable_ints();
	arch_disable_fiqs();
#endif
}

static inline void enable_native_ints(void)
{
#ifdef CONFIG_SPRD_GICV3
	arch_enable_irqs();
#else
	arch_enable_fiqs();
#endif
}

static inline void disable_native_ints(void)
{
#ifdef CONFIG_SPRD_GICV3
	arch_disable_irqs();
#else
	arch_disable_fiqs();
#endif
}

static inline void enable_foreign_ints(void)
{
#ifdef CONFIG_SPRD_GICV3
	arch_enable_fiqs();
#else
	arch_enable_ints();
#endif
}

static inline void disable_foreign_ints(void)
{
#ifdef CONFIG_SPRD_GICV3
	arch_disable_fiqs();
#else
	arch_disable_ints();
#endif
}

#endif /* __OPS_H */
