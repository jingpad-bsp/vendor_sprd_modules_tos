#define TRUETYPE_PLOAD_H   <truetype/ttpload.h>
#define TRUETYPE_OBJS_H    <truetype/ttobjs.h>
#define TRUETYPE_INTERP_H  <truetype/ttinterp.h>
#define TRUETYPE_GLOAD_H   <truetype/ttgload.h>
#define TRUETYPE_ERRORS_H  <truetype/tterrors.h>
#define TRUETYPE_DRIVERS_H <truetype/ttdriver.h>