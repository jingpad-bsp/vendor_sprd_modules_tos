#ifndef JREADER_H
#define JREADER_H

#include <stdint.h>

#define JPEG_SOF0       0xFFC0
#define JPEG_SOI        0xFFD8
#define JPEG_SOS        0xFFDA
#define JPEG_END        0xFFD9
#define JPEG_MAX_SIZE   0xFFFFFFFF
#define JPEG_MAGNIFICATION  2048

unsigned short jpeg_swap_num(unsigned short num);

typedef struct tagJPEGDATAHEADER {
    uint16_t dtype;
    uint16_t dsize;
} __attribute__((packed)) JPEGDATAHEADER;

typedef struct tagJPEGSOF0DATAHEADER {
    uint16_t dtype;
    uint16_t list_size;
    uint8_t  example_bit;
    uint16_t width;
    uint16_t height;
} __attribute__((packed)) JPEGSOF0DATAHEADER;

#endif