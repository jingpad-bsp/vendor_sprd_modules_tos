#ifndef SELIB_LOG_H_
#define SELIB_LOG_H_




int getSystemTime(int32_t* sec, int32_t* msec);
bool is_debug_enable(void);
void enable_debug(bool enable);




#define SE_LOG_TAG "[SE LIB]"
#define LOG_DBG(fmt, ...) \
{                                                                                                \
    int32_t sec = 0;                                                                             \
    int32_t msec = 0;                                                                            \
    if (getSystemTime(&sec, &msec) < 0) {                                                        \
        fprintf(stderr, "%s: %d: " fmt, SE_LOG_TAG, __LINE__,  ## __VA_ARGS__);                     \
    } else {                                                                                     \
        if(is_debug_enable())                                                                      \
            fprintf(stderr, "[%d.%d]%s: %d: " fmt, sec, msec, SE_LOG_TAG, __LINE__,  ## __VA_ARGS__);\
    }                                                                                            \
}



#endif

