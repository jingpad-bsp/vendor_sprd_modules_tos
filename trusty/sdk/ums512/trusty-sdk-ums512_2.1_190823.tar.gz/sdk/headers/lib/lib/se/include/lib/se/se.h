/*
 * Copyright (C) 2014-2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *		http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once

#include <compiler.h>
#include <sys/types.h>

#include <trusty_ipc.h>
#include <interface/se/se.h>
#include <lib/se/selib_util.h>
#include <lib/se/selib_ipc.h>
#include <lib/se/selib_log.h>


__BEGIN_CDECLS

/* GP  API Error Codes */
#define TEE_SUCCESS                       0x00000000
#define TEE_ERROR_CORRUPT_OBJECT          0xF0100001
#define TEE_ERROR_CORRUPT_OBJECT_2        0xF0100002
#define TEE_ERROR_STORAGE_NOT_AVAILABLE   0xF0100003
#define TEE_ERROR_STORAGE_NOT_AVAILABLE_2 0xF0100004
#define TEE_ERROR_GENERIC                 0xFFFF0000
#define TEE_ERROR_ACCESS_DENIED           0xFFFF0001
#define TEE_ERROR_CANCEL                  0xFFFF0002
#define TEE_ERROR_ACCESS_CONFLICT         0xFFFF0003
#define TEE_ERROR_EXCESS_DATA             0xFFFF0004
#define TEE_ERROR_BAD_FORMAT              0xFFFF0005
#define TEE_ERROR_BAD_PARAMETERS          0xFFFF0006
#define TEE_ERROR_BAD_STATE               0xFFFF0007
#define TEE_ERROR_ITEM_NOT_FOUND          0xFFFF0008
#define TEE_ERROR_NOT_IMPLEMENTED         0xFFFF0009
#define TEE_ERROR_NOT_SUPPORTED           0xFFFF000A
#define TEE_ERROR_NO_DATA                 0xFFFF000B
#define TEE_ERROR_OUT_OF_MEMORY           0xFFFF000C
#define TEE_ERROR_BUSY                    0xFFFF000D
#define TEE_ERROR_COMMUNICATION           0xFFFF000E
#define TEE_ERROR_SECURITY                0xFFFF000F
#define TEE_ERROR_SHORT_BUFFER            0xFFFF0010
#define TEE_ERROR_EXTERNAL_CANCEL         0xFFFF0011
#define TEE_ERROR_OVERFLOW                0xFFFF300F
#define TEE_ERROR_TARGET_DEAD             0xFFFF3024
#define TEE_ERROR_STORAGE_NO_SPACE        0xFFFF3041
#define TEE_ERROR_MAC_INVALID             0xFFFF3071
#define TEE_ERROR_SIGNATURE_INVALID       0xFFFF3072
#define TEE_ERROR_TIME_NOT_SET            0xFFFF5000
#define TEE_ERROR_TIME_NEEDS_RESET        0xFFFF5001
#define TEE_ERROR_61_SHORT_BUFFER         0xF0240001
#define TEE_ERROR_6C_SHORT_BUFFER         0xF0240002
#define TEE_SE_SESSION_OPEN               0x00240000





/*SE service status*/
#define SE_SERVICE_ALREADY_OPEN           0x1
#define SE_SERVICE_OPEN_SUCCES           0x0

/*SE session status*/
#define SESSION_CLOSED  0x0
#define SESSION_OPENED  0x1



/*SE handle APIs */
typedef struct __TEE_SEServiceHandle *TEE_SEServiceHandle;
typedef struct __TEE_SEReaderHandle *TEE_SEReaderHandle;
typedef struct __TEE_SESessionHandle *TEE_SESessionHandle;
typedef struct __TEE_SEChannelHandle *TEE_SEChannelHandle;

/*SE reader props*/
typedef struct {
    bool sePresent;
    bool teeOnly;
    bool selectResponseEnable;
} TEE_SEReaderProperties;



/*SE aid*/
typedef struct {
    uint8_t *buffer;
    size_t bufferLen;
} TEE_SEAID;




typedef uint32_t TEE_Result;



#define TEE_SE_READER_NAME_MAX 20
#define MAX_ATR_SIZE   100




/*GP SE OPEN MOBIA API*/
TEE_Result TEE_SEServiceOpen(TEE_SEServiceHandle *seServiceHandle);

void TEE_SEServiceClose(TEE_SEServiceHandle seServiceHandle);

TEE_Result TEE_SEServiceGetReaders(
        TEE_SEServiceHandle seServiceHandle,
        TEE_SEReaderHandle *seReaderHandleList,
        size_t *seReaderHandleListLen);

void TEE_SEReaderGetProperties(TEE_SEReaderHandle seReaderHandle,
        TEE_SEReaderProperties *readerProperties);

TEE_Result TEE_SEReaderGetName(TEE_SEReaderHandle seReaderHandle,
        char *readerName, size_t *readerNameLen);

TEE_Result TEE_SEReaderOpenSession(TEE_SEReaderHandle seReaderHandle,
        TEE_SESessionHandle *seSessionHandle);

void TEE_SEReaderCloseSessions(TEE_SEReaderHandle seReaderHandle);

TEE_Result TEE_SESessionGetATR(TEE_SESessionHandle seSessionHandle,
        void *atr, size_t *atrLen);

TEE_Result TEE_SESessionIsClosed(TEE_SESessionHandle seSessionHandle);

void TEE_SESessionClose(TEE_SESessionHandle seSessionHandle);

void TEE_SESessionCloseChannels(TEE_SESessionHandle seSessionHandle);


TEE_Result TEE_SESessionOpenBasicChannel(TEE_SESessionHandle seSessionHandle,
        TEE_SEAID *seAID, TEE_SEChannelHandle *seChannelHandle);

TEE_Result TEE_SESessionOpenLogicalChannel(TEE_SESessionHandle seSessionHandle,
        TEE_SEAID *seAID, TEE_SEChannelHandle *seChannelHandle);

TEE_Result TEE_SEChannelSelectNext(TEE_SEChannelHandle seChannelHandle);

TEE_Result TEE_SEChannelGetSelectResponse(TEE_SEChannelHandle seChannelHandle,
        void *response, size_t *responseLen);

TEE_Result TEE_SEChannelTransmit(TEE_SEChannelHandle seChannelHandle,
        void *command, uint32_t commandLen,
        void *response, uint32_t *responseLen);

void TEE_SEChannelClose(TEE_SEChannelHandle seChannelHandle);

TEE_Result TEE_SEChannelGetResponseLength(TEE_SEChannelHandle seChannelHandle, size_t *responseLen);


/*private debug API*/
void TEE_SEDebugOpen(bool enable);

void TEE_SETest(void);


__END_CDECLS

