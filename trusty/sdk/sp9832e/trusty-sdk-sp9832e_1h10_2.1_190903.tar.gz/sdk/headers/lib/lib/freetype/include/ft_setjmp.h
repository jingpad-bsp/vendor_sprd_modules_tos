#ifndef SETJMP_H
#define SETJMP_H

#define _JBFP 1
#define _JBMOV 60
#define _JBOFF 4
#define _NSETJMP 17

typedef int freetype_jmp_buff[_NSETJMP];

unsigned long freetype_getfp(void);
int freetype_setjmp(freetype_jmp_buff env);
void freetype_setfp(int fp);
//static void freetype_quit(int fp);

int freetype_dojmp(freetype_jmp_buff env);
void freetype_longjmp(freetype_jmp_buff env,int val);
char *freetype_stackptr(void);

#endif