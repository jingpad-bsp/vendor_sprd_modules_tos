/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Helper functions for storing integer values into byte streams.
   No bounds checking is performed, that is the responsibility of the caller. */

#ifndef WOFF2_STORE_BYTES_H_
#define WOFF2_STORE_BYTES_H_

#include <inttypes.h>
#include <stddef.h>
#include <brotli/string.h>

size_t StoreU32_32(uint8_t* dst, size_t offset, uint32_t x);
size_t Store16_16(uint8_t* dst, size_t offset, int x);
void StoreU32_8(uint32_t val, size_t* offset, uint8_t* dst);
void Store16_8(int val, size_t* offset, uint8_t* dst); 

#endif  // WOFF2_STORE_BYTES_H_
