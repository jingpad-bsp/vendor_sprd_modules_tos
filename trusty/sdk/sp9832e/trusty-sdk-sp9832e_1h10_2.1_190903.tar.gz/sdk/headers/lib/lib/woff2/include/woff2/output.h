/* Copyright 2016 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Output buffer for WOFF2 decompression. */

#ifndef WOFF2_WOFF2_OUT_H_
#define WOFF2_WOFF2_OUT_H_

#include <woff2/woff2_common.h>
#include <stdint.h>

// Suggested max size for output.
//const size_t kDefaultMaxSize = 30 * 1024 * 1024;

/**
 * Output interface for the woff2 decoding.
 *
 * Writes to arbitrary offsets are supported to facilitate updating offset
 * table and checksums after tables are ready. Reading the current size is
 * supported so a 'loca' table can be built up while writing glyphs.
 *
 * By default limits size to kDefaultMaxSize.
 */

typedef struct WOFF2MemoryOut{
  uint8_t* buf_;
  size_t buf_size_;
  size_t offset_;
}WOFF2MemoryOut;

void WOFF2MemoryOutInit(WOFF2MemoryOut* w2m_out, uint8_t* buf, size_t buf_size);
int WOFF2MemoryWriteDefault(WOFF2MemoryOut* w2m_out, const void *buf, size_t n);
int WOFF2MemoryWrite(WOFF2MemoryOut* w2m_out, const void *buf, size_t offset, size_t n);

#endif  // WOFF2_WOFF2_OUT_H_
