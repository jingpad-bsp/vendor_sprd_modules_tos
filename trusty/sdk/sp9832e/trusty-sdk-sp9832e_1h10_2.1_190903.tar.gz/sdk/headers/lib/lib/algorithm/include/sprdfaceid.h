/*-------------------------------------------------------------------*/
/*  Copyright(C) 2018 by Spreadtrum                                  */
/*  All Rights Reserved.                                             */
/*-------------------------------------------------------------------*/
/* 
    FaceID library API
*/

#ifndef __SPRD_FACEID_API_H__
#define __SPRD_FACEID_API_H__

#include <stdint.h>

#if (defined( WIN32 ) || defined( WIN64 )) && (defined FACEIDAPI_EXPORTS)
#define FACEID_EXPORTS __declspec(dllexport)
#else
#define FACEID_EXPORTS
#endif

#ifndef FACEIDAPI
#define FACEIDAPI(rettype) extern FACEID_EXPORTS rettype
#endif

/*
 * Error codes
 */
#define FACEID_OK                   0     // Successfully extract face feature
#define FACEID_FAIL_NO_FACE         1     // Fail: no face detected
#define FACEID_FAIL_MULTI_FACE      2     // Fail: multi face detected
#define FACEID_FAIL_LIVENESS        3     // Fail: liveness check failed
#define FACEID_FAIL_EYECLOSE        4     // Fail: eye is closed
#define FACEID_FAIL_OCCLUSION       5     // Fail: face is occluded
#define FACEID_FAIL_BLUR            6     // Fail: face is blurred
#define FACEID_FAIL_OUTOFIMAGE		7 //Fail: face is out of image.
#define FACEID_FAIL_MOVINGFAST		8// Fail: face is moving fast.
#define FACEID_FAIL_NOTGOODFACE     9     // // Fail: face is not a good pose.(near/far/not a good angle)
#define FACEID_FAIL_AENOTCONVERGED  10    // Fail: ae not converged.
#define FACEID_FAIL_NOTGOODBRIGHT   11    // Fail: not a good brightness.
#define FACEID_ERROR_INTERNAL       -1    // Error: Unknown internal error
#define FACEID_ERROR_NOMEMORY       -2    // Error: Memory allocation error
#define FACEID_ERROR_INVALIDARG     -3    // Error: Invalid argument

/*
 * Work Stage
 */
#define ENROLL_STAGE                 0    // In enroll stage
#define AUTHENTICATE_STAGE           1    // In authenticate stage

#define FIT_POSE                     1
/*
 * A YUV 4:2:0 image with a plane of 8bit Y samples followed by an
 * interleaved U/V planes.
 */
typedef struct
{
    unsigned char *yData; /* Y data pointer                          */
    unsigned char *uvData;/* UV data pointer                         */
    int32_t width;        /* Image width                             */
    int32_t height;       /* Image height                            */
    uint8_t format;       /* Image format. 0->NV12; 1->NV21          */
                          /* NV12 format; pixel order:  CbCrCbCr     */
                          /* NV21 format; pixel order:  CrCbCrCb     */
} FACEID_IMAGE_YUV420SP;

/*
 * The FACEID feature vector
 */
#define FACEID_FEATURE_LENGTH       512
#define FACEID_FEATURE_TYPE			float
typedef struct
{
    FACEID_FEATURE_TYPE data[FACEID_FEATURE_LENGTH];
} FACEID_FEATURE;


/*
 * The Stereo-camera OTP data (Camera calibration parameters)
 */
typedef struct 
{
    void *data;               // OTP data
    int32_t size;             // OTP data size (in bytes)
    int32_t otpImageWidth;    // The image width used for camera calibration
    int32_t otpImageHeight;   // The image height used for camera calibration
    int32_t cameraAlignDir;   // Camera alignment direction. The direction is defined relative to the image width. 
                              // 0: aligned on horizontal diretion.
                              // 1: aligned on vertical direction.
} FACEID_STEREOCAMERA_OTP;

typedef struct
{
    int32_t frontOcclusionThr;      // frontal face occlusion Thr
    int32_t frontClarityThr;        // frontal face blur Thr
    int32_t upOcclusionThr;         // up face occlusion Thr
    int32_t upClarityThr;           // up face blur Thr
    int32_t downOcclusionThr;       // down face occlusion Thr 
    int32_t downClarityThr;         // down face blur Thr
} FACEID_BLUROCCLUSION_THR;

typedef struct
{
    int32_t yawAngle;               // the yaw angle range of frontal face
    int32_t pitchAngleFrontOne;     // the pitch angle thr of frontal face
    int32_t pitchAngleFrontTwo;     // the pitch angle thr of frontal face
    int32_t pitchAngleUpOne;        // the pitch angle thr of up face
    int32_t pitchAngleUpTwo;        // the pitch angle thr of up face
    int32_t pitchAngleDownOne;      // the pitch angle thr of down face
    int32_t pitchAngleDownTwo;      // the pitch angle thr of down face
} FACEID_ENROLLANGLE_THR;

typedef struct
{
    uint32_t count;         // template count
    int32_t prePitchAngle; // enroll finished and failed
} FRAME_STATE;

typedef struct
{
    float authThr;
} FACEID_OUTINFO;
/*
 * The FACEID option
 */
typedef struct 
{
    uint8_t checkLiveness;                        // whether to check face liveness
    uint8_t checkEyeOpen;                         // whether to check the eye is open or not
    int32_t livenessThr;                          // The threshold for liveness detection[-100, 100]
    int32_t eyeOpenThrOne;                        // The threshold for eye open detection[-100, 100]
    int32_t eyeOpenThrTwo;                        // The threshold for eye open detection[-100, 100]
    int32_t eyeOpenThrThree;                      // The threshold for eye open detection[-100, 100]
    int32_t eyeCloseThrOne;                       // The threshold for eye close detection[-100, 100]
    int32_t eyeCloseThrTwo;                       // The threshold for eye close detection[-100, 100]
    int32_t eyeCloseThrThree                    ; // The threshold for eye close detection[-100, 100]
    int32_t occlusionThr;                         // The threshold for occlusion detection[-100, 100]
    int32_t clarityThr;                           // The threshold for clarity detection[-100, 100]
    int32_t minFaceSizePct;                       // The min face size percent: minFaceSize / image size * 100
    int32_t fvVersion;                            // The face verify version to choose fv model [0, 1]
    uint8_t workStage;                            // The work stage is enroll(0) or authenticate(1)
    int32_t enrollFaceSizeThrOne;                 // The min threshold for face size enrolled;
    int32_t enrollFaceSizeThrTwo;                 // The max threshold for face size enrolled;
    FACEID_BLUROCCLUSION_THR occlusionBlurThr;    // The enroll threshold for ocllusion and blur detection.
    FACEID_ENROLLANGLE_THR enrollAngleThr;        // The enroll threshold for yaw and pitch angle.
} FACEID_OPTION;

/* The face information structure */
typedef struct {
    int x, y, width, height;          /* Face rectangle                           */
    int yawAngle;                     /* Out-of-plane rotation angle (Yaw);In [-90, +90] degrees;   */
#if FIT_POSE
    int pitchAngle;
#endif
} FACEID_FACEINFO;


/* Internal face image structure */
typedef struct
{
    unsigned char *data;    /* image data       */
    int width;              /* image width      */
    int height;             /* image height     */
    int step;               /* the byte count per scan line */
    int planes;             /* number of image planes */
} FACEID_Image_t;

typedef struct
{
    int x, y;
}FACEID_POINT;

/* The face point information structure */
typedef struct
{
    FACEID_POINT landmarks[7]; /* The facial landmark points. The sequence is: Two left-eye corner points
                                Two right-eye corner points, nose tip, mouth left corner, mouth right corner
                               */
}FACEID_FACEPOINTINFO;
/*
 * Help info from hal.
 * The first part: one int32 is CONTROL_AE_STATE;
 * The second part: one int32 is ae info. Bit 31-16 is the bv value,which is a signed value. 
 *                              Bit 10-1 is the probability of backlight, range[0-1000].
 *                              Bit 0 is whether ae is stable, range[0, 1].
 * The third part: 256 int32 is hist_statistics.
 * The fouth part: one int32 is the phone orientation info.
 */
typedef struct
{
    const int32_t *helpInfo;
    int32_t count;
} FACEID_HELPINFO;

/*
 * The FACEID handle
 */
typedef void * FACEID_HANDLE;

#ifdef  __cplusplus
extern "C" {
#endif

/*
 * Get the software version
 */
FACEIDAPI(const char *) FACEID_GetVersion();

/*
 * Initialize the FACEID_OPTION structure by default values
 */
FACEIDAPI(void) FACEID_InitOption(FACEID_OPTION *option);

/*
 * Create the FACEID handle
 * 
 * Returns FACEID_OK if successful. Returns negative numbers otherwise.
 */
FACEIDAPI(int32_t) FACEID_CreateHandle(FACEID_HANDLE *hFACEID, 
                                       const FACEID_OPTION *option);

/*
 * Release the FACEID handle
 */
FACEIDAPI(void) FACEID_DeleteHandle(FACEID_HANDLE *hFACEID);


/*
 * Extract face feature from YUV420SP image
 * 
 * Returns FACEID_OK: if successful extract the feature
 *         FACEID_FAIL_NO_FACE: if no face detected
 *         FACEID_FAIL_LIVENESS: if liveness check failed
 *         FACEID_FAIL_EYECLOSE: if the eyes are closed
 *         Negative numbers: if error occurred.
 */
FACEIDAPI(int32_t) FACEID_ExtractFeature_YUV(FACEID_HANDLE hFACEID,
                                             const FRAME_STATE i_frameStatus,
                                             const FACEID_IMAGE_YUV420SP *yuvImage,
                                             const FACEID_HELPINFO *helpInfo,
                                             FACEID_FEATURE *feature,
                                             FACEID_FACEINFO *faceInfo,
                                             FACEID_FACEPOINTINFO *facePointInfo,
                                             FACEID_OUTINFO *outInfo);

/**
 * Save face image for upgrade
 * 
 * Returns 0 if successful; otherwise returns negative number
 */
FACEIDAPI(int32_t) FACEID_ExtractFaceImage_YUV(FACEID_HANDLE hFACEID,
                                            const FACEID_IMAGE_YUV420SP *yuvImage,
                                            FACEID_FACEPOINTINFO *facePointInfo,
                                            FACEID_Image_t *faceImage);

/**
 * Extract face feature from saved face image for upgrade
 * 
 * Returns 0 if successful; otherwise returns negative number
 */
FACEIDAPI(int32_t) FACEID_ExtractFeatureFromFaceImage(FACEID_HANDLE hFACEID,
                                                      FACEID_Image_t *faceImage,
                                                      FACEID_FEATURE *feature);

/*
 * Extract face feature from dual-camera images
 * 
 * Returns FACEID_OK: if successful extract the feature
 *         FACEID_FAIL_NO_FACE: if no face detected
 *         FACEID_FAIL_LIVENESS: if liveness check failed
 *         FACEID_FAIL_EYECLOSE: if the eyes are closed
 *         Negative numbers: if error occurred.
 */
FACEIDAPI(int32_t) FACEID_ExtractFeature_Stereo(FACEID_HANDLE hFACEID,
                                                const FRAME_STATE i_frameStatus,
                                                const FACEID_STEREOCAMERA_OTP *otp,
                                                const FACEID_IMAGE_YUV420SP *mainImage,
                                                const FACEID_IMAGE_YUV420SP *subImage,
                                                const FACEID_HELPINFO *helpInfo,
                                                FACEID_FEATURE *feature,
                                                FACEID_FACEINFO *faceInfo,
                                                FACEID_FACEPOINTINFO *facePointInfo,
                                                FACEID_OUTINFO *outInfo);

/*
 * Calculate the similarity of two face features
 * 
 * Returns the face similarity score
 */
FACEIDAPI(float) FACEID_MatchFace(const FACEID_FEATURE *featureA, 
                                  const FACEID_FEATURE *featureB); 


#ifdef  __cplusplus
}
#endif

#endif /* __SPRD_FACEID_API_H__ */
