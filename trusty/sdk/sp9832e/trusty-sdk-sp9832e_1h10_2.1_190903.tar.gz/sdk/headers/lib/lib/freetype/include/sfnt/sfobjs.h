/***************************************************************************/
/*                                                                         */
/*  sfobjs.h                                                               */
/*                                                                         */
/*    SFNT object management (specification).                              */
/*                                                                         */
/*  Copyright 1996-2001, 2002 by                                           */
/*  David Turner, Robert Wilhelm, and Werner Lemberg.                      */
/*                                                                         */
/*  This file is part of the FreeType project, and may only be used,       */
/*  modified, and distributed under the terms of the FreeType project      */
/*  license, LICENSE.TXT.  By continuing to use, modify, or distribute     */
/*  this file you indicate that you have read the license and              */
/*  understand and accept it fully.                                        */
/*                                                                         */
/***************************************************************************/


#ifndef __SFOBJS_H__
#define __SFOBJS_H__


#include <ft2build.h>
#include FT_INTERNAL_SFNT_H
#include FT_INTERNAL_OBJECTS_H

/***************************************************************************
 *
 * @constant:
 *   FT_PARAM_TAG_IGNORE_PREFERRED_FAMILY
 *
 * @description:
 *   A constant used as the tag of @FT_Parameter structures to make
 *   FT_Open_Face() ignore preferred family subfamily names in `name'
 *   table since OpenType version 1.4.  For backwards compatibility with
 *   legacy systems that have a 4-face-per-family restriction.
 *
 */
#define FT_PARAM_TAG_IGNORE_PREFERRED_FAMILY  FT_MAKE_TAG( 'i', 'g', 'p', 'f' )


/***************************************************************************
 *
 * @constant:
 *   FT_PARAM_TAG_IGNORE_PREFERRED_SUBFAMILY
 *
 * @description:
 *   A constant used as the tag of @FT_Parameter structures to make
 *   FT_Open_Face() ignore preferred subfamily names in `name' table since
 *   OpenType version 1.4.  For backwards compatibility with legacy
 *   systems that have a 4-face-per-family restriction.
 *
 */
#define FT_PARAM_TAG_IGNORE_PREFERRED_SUBFAMILY  FT_MAKE_TAG( 'i', 'g', 'p', 's' )


FT_BEGIN_HEADER
FT_LOCAL(FT_Error)
sfnt_init_face(FT_Stream      stream,
               TT_Face        face,
               FT_Int         face_index,
               FT_Int         num_params,
               FT_Parameter  *params);

FT_LOCAL(FT_Error)
sfnt_load_face(FT_Stream      stream,
               TT_Face        face,
               FT_Int         face_index,
               FT_Int         num_params,
               FT_Parameter  *params);

FT_LOCAL(void)
sfnt_done_face(TT_Face  face);


FT_END_HEADER

#endif /* __SFDRIVER_H__ */


/* END */
