#ifndef WOFF2_BUFFER_C_H_
#define WOFF2_BUFFER_C_H_

#include <woff2/tnet.h>
#include <brotli/types.h>
#include <brotli/string.h>

#define false 0
#define true  1

#define PREDICT_FALSE(x) (x)
#define PREDICT_TRUE(x) (x)

#define FONT_COMPRESSION_FAILURE() false;


typedef struct Buffer_REC_ {
  const uint8_t * buffer_;
  size_t length_;
  size_t offset_;
}Buffer;

void Buffer_init(Buffer * buffer, const uint8_t *data, size_t len);
int Skip(Buffer * buffer, size_t n_bytes);
int Read(Buffer * buffer, uint8_t *data, size_t n_bytes);
int ReadU8(Buffer * buffer, uint8_t *value);
int ReadU16(Buffer * buffer, uint16_t *value);
int ReadS16(Buffer * buffer, int16_t *value);
int ReadU32(Buffer * buffer, uint32_t *value);

#endif