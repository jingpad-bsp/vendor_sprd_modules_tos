/***************************************************************************/
/*                                                                         */
/*  ttdriver.h                                                             */
/*                                                                         */
/*    High-level TrueType driver interface (specification).                */
/*                                                                         */
/*  Copyright 1996-2001, 2002 by                                           */
/*  David Turner, Robert Wilhelm, and Werner Lemberg.                      */
/*                                                                         */
/*  This file is part of the FreeType project, and may only be used,       */
/*  modified, and distributed under the terms of the FreeType project      */
/*  license, LICENSE.TXT.  By continuing to use, modify, or distribute     */
/*  this file you indicate that you have read the license and              */
/*  understand and accept it fully.                                        */
/*                                                                         */
/***************************************************************************/


#ifndef __TTDRIVER_H__
#define __TTDRIVER_H__


#include <ft2build.h>
#include FT_INTERNAL_DRIVER_H

#define TT_SERVICES_GET                  tt_services
#define TT_SERVICE_GX_MULTI_MASTERS_GET  tt_service_gx_multi_masters
#define TT_SERVICE_TRUETYPE_GLYF_GET     tt_service_truetype_glyf
#define TT_SERVICE_PROPERTIES_GET        tt_service_properties


FT_BEGIN_HEADER


FT_DECLARE_DRIVER(tt_driver_class)


FT_END_HEADER

#endif /* __TTDRIVER_H__ */


/* END */
