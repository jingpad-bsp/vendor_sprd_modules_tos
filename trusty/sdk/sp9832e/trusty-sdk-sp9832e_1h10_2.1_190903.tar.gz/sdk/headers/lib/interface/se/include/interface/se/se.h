/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once


/*TA call SE SERVER TA*/
#define SE_SECURE_PORT "com.android.trusty.se.secure"


/**
 * enum se_cmd - command identifiers for se functions
 */
enum se_cmd {
    SE_REQ_SHIFT = 1,
    SE_RESP_BIT  = 1,

    SE_GET_READERS       = (0 << SE_REQ_SHIFT),
    SE_GET_READER_PROP       = (1 << SE_REQ_SHIFT),
    SE_GET_READER_NAME       = (2 << SE_REQ_SHIFT),
    SE_OPEN_SESSION       = (3 << SE_REQ_SHIFT),
    SE_READER_CLOSE_SESSIONS       = (4 << SE_REQ_SHIFT),
    
    SE_SESSION_GET_ATR     = (5 << SE_REQ_SHIFT),
    SE_SESSION_IS_CLOSED       = (6 << SE_REQ_SHIFT),
    SE_SESSION_CLOSE       = (7 << SE_REQ_SHIFT),
    SE_SESSION_CLOSE_CHANNELS      = (8 << SE_REQ_SHIFT),
    SE_SESSION_OPEN_BASIC_CHANNEL      = (9 << SE_REQ_SHIFT),
    SE_SESSION_OPEN_LOGICAL_CHANNEL    = (10 << SE_REQ_SHIFT),
    
    SE_CHANNEL_CLOSE       = (11 << SE_REQ_SHIFT),
    SE_CHANNEL_SELECT_NEXT     = (12 << SE_REQ_SHIFT),
    SE_CHANNEL_GET_SELECT_RESPONSE     = (13 << SE_REQ_SHIFT),
    SE_CHANNEL_TRANSMIT    = (14 << SE_REQ_SHIFT),
    SE_CHANNEL_GET_RESPONSE_LENGTH     = (15 << SE_REQ_SHIFT),

    SE_SERVICE_OPEN   = (16 << SE_REQ_SHIFT),
    SE_SERVICE_CLOSE   = (17 << SE_REQ_SHIFT),

    SE_SET_DEBUG   = (18 << SE_REQ_SHIFT),
    SE_TEST       = (20 << SE_REQ_SHIFT),

};



struct se_msg {
    uint32_t cmd;
    uint8_t payload[0];
};

