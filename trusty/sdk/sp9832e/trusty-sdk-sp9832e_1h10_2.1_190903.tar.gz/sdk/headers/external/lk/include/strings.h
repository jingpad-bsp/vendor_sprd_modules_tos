#if !defined(__STRINGS_H)
#define __STRINGS_H

int strcasecmp(const char *s1, const char *s2);

#endif  /* !__STRINGS_H */
