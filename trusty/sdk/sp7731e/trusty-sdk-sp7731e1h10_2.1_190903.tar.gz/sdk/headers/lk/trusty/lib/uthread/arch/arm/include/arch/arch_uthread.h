/*
 * Copyright (c) 2013, Google Inc. All rights reserved
 * Copyright (c) 2012-2013, NVIDIA CORPORATION. All rights reserved
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#ifndef __ARM_ARCH_UTHREAD_H
#define __ARM_ARCH_UTHREAD_H

#include <list.h>

struct uthread;

/* @ Page table layout
 *
 * L1: |  E(0)  |  E(1)  |  E(2)  |  E(3)  | .. | E(n) | --> n<=4096
 *     ^   ^                               ^
 *     |   |                               |
 *     |   4 bytes per entry               |
 *     +----- 4 entries points to one page +
 *
 * L2: [ T(0,0) | T(0,1) | T(0,2) | T(0,3) ] .. | T(n) | --> n tables
 *     ^    ^                              ^
 *     |    |                              |
 *     |    max 256 entries per table      |
 *     +---   256x4x4 bytes(1 page)    --- +
 *
 * @ Use of each member of 'struct arch_uthread'
 * asid: software used asid, NOT hardware asid. Only its significant bits will
 *       be written to TTBR
 *
 * l2_table_entries: l2 total entries in each grouped l2 table
 * l2_table_entries[0] = active_entries(T(0,0)) + .. + active_entries(T(0,3))
 * ...
 * l2_table_entries[t] = active_entries(T(t,0)) + .. + active_entries(T(t,3))
 *
 * l2_table_list: links the pages used by the tables
 */
struct arch_uthread
{
	uint32_t asid;

	uint *l2_table_entries;
	struct list_node l2_table_list;
	struct uthread *uthread;
};

#endif
