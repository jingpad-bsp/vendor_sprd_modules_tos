#include <lib/trusty/trusty_app.h>

struct trusty_app_elfloader {
	status_t (*loader_probe)(struct trusty_app_img *img);
	trusty_app_t * (*create_app)(struct trusty_app_img *img);
	status_t (*alloc_vma)(trusty_app_t *trusty_app);

	struct list_node node;
	uint fmt;
};

extern void trusty_app_register_elfloader(struct trusty_app_elfloader *elfloader);

