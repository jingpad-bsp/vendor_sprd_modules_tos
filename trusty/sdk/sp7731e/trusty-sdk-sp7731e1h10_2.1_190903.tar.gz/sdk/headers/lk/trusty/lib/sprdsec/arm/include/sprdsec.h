/*
 * Copyright (c) 2016 spreadtrum, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files
 * (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#ifndef _SPRD_SEC_H_
#define _SPRD_SEC_H_
#define FUNCTYPE_VERIFY_IMG 0x1
#define FUNCTYPE_SET_SECURE_RANGE_PARAM 0x9
#define FUNCTYPE_GET_HBK 0x08
/*add fastboot cmd for sharkl2*/
#define FUNCTYPE_GET_SOCID 0x03
#define FUNCTYPE_GET_LCS 0x0A
#define FUNCTYPE_SET_RMA 0x0B

#define FUNCTYPE_VBOOT_VERIFY_IMG 0x20
#define FUNCTYPE_VBOOT_SET_VERSION 0x21
#define FUNCTYPE_SET_RPMB_SIZE 0x22
#define FUNCTYPE_IS_WR_RPMB_KEY 0x23
#define FUNCTYPE_CHECK_RPMB_KEY 0x24

/*add for vboot*/
#define FUNCTYPE_SET_BINDING_DATA   0x30
#define FUNCTYPE_CRYPTO_DATA 0x31
#define FUNCTYPE_CHECK_PWD 0x32
#define FUNCTYPE_CHECK_LOCK_STATUS 0x33
#define FUNCTYPE_VERIFY_PRODUCT_SN_SIGNATURE 0x34
#define FUNCTYPE_CONFIG_OS_VERSION 0x35
#define FUNCTYPE_SET_ROOT_OF_TRUST 0x36

// hunter.ding add for SOTER-start
#if defined (CONFIG_CHIP_UID)
#define FUNCTYPE_SET_CHIP_UID          0x40
#endif
// hunter.ding add for SOTER-end

#ifndef PAGE_SIZE
#define PAGE_SIZE (4096)
#endif

#define VBOOT_DEFAULT_OEM_UNLOCK_PWD	("ab#AB")

#define DEFAULT_DEV_STATE	("VerifiedBoot-LOCK")  /*warning:data before encrypt*/
#define LOCK_DEV_STATE		DEFAULT_DEV_STATE
#define UNLOCK_DEV_STATE	         ("VerifiedBoot-UNLOCK")  /*warning:data before encrypt*/
#define DEFAULT_DEV_STATE_LEN	(64)
#define DERIVE_HUK	         ("VerifiedBoot-HUK-DERIVE")  /*warning:to product key derived by huk*/

#define PDT_INFO_LOCK_FLAG_MAX_SIZE (64)
#define PDT_INFO_UNLOCK_PWD_MAX_SIZE (64)

#define VBOOT_UNLOCK_PWD_CHECK_FAIL (1)
#define VBOOT_UNLOCK_PWD_CHECK_SUCC (0)

#define VBOOT_LOCK_STATE_LOCK (0)
#define VBOOT_LOCK_STATE_UNLOCK (1)

typedef struct {
    uint8_t val[PAGE_SIZE];
    uint32_t len;
} ns_data_t;

typedef enum {
    SEC_ROOT_TRUST,
    SEC_PUBLIC_KEY,
    SEC_HW_KEY,
    SEC_RNG,
    SEC_DEVICE_STATE,
// hunter.ding add for SOTER-start
#if defined (CONFIG_CHIP_UID)
    SEC_CHIP_UID,
#endif
// hunter.ding add for SOTER-end
    SEC_OS_VERSION,
    SEC_MAX
} cmd_info;

typedef struct {
    uint32_t os_version;			/* os_version = (A * 100 + B) * 100 + C  (A.B.C) */
    uint32_t os_patch_level;		/* os_patch_level = Y * 100 + M (Y-M-D) */
}VbootSystemVersionInfo;

typedef enum {
    VERIFIED_BOOT_VERIFIED = 0,    /* Full chain of trust extending from the bootloader to
                                       * verified partitions, including the bootloader, boot
                                       * partition, and all verified partitions*/
    VERIFIED_BOOT_SELF_SIGNED = 1, /* The boot partition has been verified using the embedded
                                       * certificate, and the signature is valid. The bootloader
                                       * displays a warning and the fingerprint of the public
                                       * key before allowing the boot process to continue.*/
    VERIFIED_BOOT_UNVERIFIED = 2,  /* The device may be freely modified. Device integrity is left
                                       * to the user to verify out-of-band. The bootloader
                                       * displays a warning to the user before allowing the boot
                                       * process to continue */
    VERIFIED_BOOT_FAILED = 3,      /* The device failed verification. The bootloader displays a
                                       * warning and stops the boot process, so no keymaster
                                       * implementation should ever actually return this value,
                                       * since it should not run.  Included here only for
                                       * completeness. */
} verified_boot_t;

typedef enum {
    DEVICE_UNLOCKED = 0,
    DEVICE_LOCKED = 1,
} device_locked_t;

typedef enum {
    ROOT_OF_TRUST_NOT_READY = 0,
    ROOT_OF_TRUST_READY = 1,
} ROOT_OF_TRUST_STATE;

#define VERIFIED_BOOT_KEY_MAX_LENGTH        (32)
#define VERIFIED_BOOT_HASH_MAX_LENGTH       (64)
#define ROOT_OF_TRUST_MAX_LENGTH            (1024)
/* The root_of_trust structure */
typedef struct root_of_trust {
    device_locked_t device_locked;
    verified_boot_t verified_boot_state;
    uint32_t verified_boot_key_len;
    uint8_t verified_boot_key[VERIFIED_BOOT_KEY_MAX_LENGTH];
    uint32_t verified_boot_hash_len;
    uint8_t verified_boot_hash[VERIFIED_BOOT_HASH_MAX_LENGTH];
} ROOT_OF_TRUST;

extern ns_data_t s_ns_key[];
void save_ns_data(cmd_info id, void *vaddr, uint32_t len);
#endif

