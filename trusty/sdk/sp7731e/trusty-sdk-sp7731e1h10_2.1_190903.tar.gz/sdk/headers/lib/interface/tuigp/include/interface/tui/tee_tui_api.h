#ifndef ___TEE_TUI_API_H__
#define ___TEE_TUI_API_H__


#include <stddef.h>/* for size_t */
#include <stdbool.h>

////////////////////////////////////////////////////////////////
//    COMMON LOCAL TYPES
////////////////////////////////////////////////////////////////
typedef unsigned int    uint32_t;
typedef signed int      int32_t;

typedef unsigned short  uint16_t;
typedef signed short    int16_t;

typedef unsigned char   uint8_t;
typedef signed char     int8_t;


////////////////////////////////////////////////////////////////
//    GP TYPES
////////////////////////////////////////////////////////////////
typedef uint32_t TEE_Result;

////////////////////////////////////////////////////////////////
//    ERROR CODE  (with type as TEE_Result)
////////////////////////////////////////////////////////////////
#define      TEE_SUCCESS                        0x00000000U
#define      TEE_ERROR_CORRUPT_OBJECT           0xF0100001U
#define      TEE_ERROR_CORRUPT_OBJECT_2         0xF0100002U
#define      TEE_ERROR_STORAGE_NOT_AVAILABLE    0xF0100003U
#define      TEE_ERROR_STORAGE_NOT_AVAILABLE_2  0xF0100004U
#define      TEE_ERROR_GENERIC                  0xFFFF0000U
#define      TEE_ERROR_ACCESS_DENIED            0xFFFF0001U
#define      TEE_ERROR_CANCEL                   0xFFFF0002U
#define      TEE_ERROR_ACCESS_CONFLICT          0xFFFF0003U
#define      TEE_ERROR_EXCESS_DATA             0xFFFF0004U
#define      TEE_ERROR_BAD_FORMAT               0xFFFF0005U
#define      TEE_ERROR_BAD_PARAMETERS           0xFFFF0006U
#define      TEE_ERROR_BAD_STATE                0xFFFF0007U
#define      TEE_ERROR_ITEM_NOT_FOUND           0xFFFF0008U
#define      TEE_ERROR_NOT_IMPLEMENTED          0xFFFF0009U
#define      TEE_ERROR_NOT_SUPPORTED            0xFFFF000AU
#define      TEE_ERROR_NO_DATA                  0xFFFF000BU
#define      TEE_ERROR_OUT_OF_MEMORY            0xFFFF000CU
#define      TEE_ERROR_BUSY                     0xFFFF000DU
#define      TEE_ERROR_COMMUNICATION            0xFFFF000EU
#define      TEE_ERROR_SECURITY                 0xFFFF000FU
#define      TEE_ERROR_SHORT_BUFFER             0xFFFF0010U
#define      TEE_ERROR_EXTERNAL_CANCEL          0xFFFF0011U
#define      TEE_ERROR_OVERFLOW                 0xFFFF300FU
#define      TEE_ERROR_TARGET_DEAD              0xFFFF3024U
#define      TEE_ERROR_STORAGE_NO_SPACE         0xFFFF3041U
#define      TEE_ERROR_MAC_INVALID              0xFFFF3071U
#define      TEE_ERROR_SIGNATURE_INVALID        0xFFFF3072U
#define      TEE_ERROR_TIME_NOT_SET             0xFFFF5000U
#define      TEE_ERROR_TIME_NEEDS_RESET         0xFFFF5001U



////////////////////////////////////////////////////////////////
//   PROPERTIES
////////////////////////////////////////////////////////////////

//true if a security indicator is present on TUI screens by default. It means that a security indicator is managed by the TEE. 
//If false, a security indicator MUST be managed by the TA itself.
extern bool gpd_tee_tui_securityIndicator;// = true;

//The list of supported languages separated by ':'. The language names are based on the ISO 639-1 codes[ISO 639-1].
extern const char* gpd_tee_tui_languages;// = "en";//"en:zh";

//0x00000001 if it is possible to request the display of TUI screens with portrait orientation, i.e. vertical orientation only.
//0x00000002 if it is possible to request the display of TUI screens with landscape orientation, i.e. horizontal orientation only.
//0x00000003 if it is possible to requestthe display of TUI screens with portrait or landscape orientation, i.e. vertical or horizontal orientation
extern int gpd_tee_tui_orientation;// = 0;//0x00000001;

//Duration of the timeout associated with a TUI session in milliseconds. Typical value is around 10 seconds.
extern int gpd_tee_tui_session_timeout;// = 10;


////////////////////////////////////////////////////////////////
//   CONSTANTS
////////////////////////////////////////////////////////////////
// see TEE_TUIButtonType
//static const uint32_t TEE_TUI_NUMBER_BUTTON_TYPES = 0x00000006;
#define TEE_TUI_NUMBER_BUTTON_TYPES 0x00000006


////////////////////////////////////////////////////////////////
//   STRUCTURES
////////////////////////////////////////////////////////////////
typedef enum
{
    TEE_TUI_CORRECTION = 0,
    TEE_TUI_OK,
    TEE_TUI_CANCEL,
    TEE_TUI_VALIDATE,
    TEE_TUI_PREVIOUS,
    TEE_TUI_NEXT
} TEE_TUIButtonType;

typedef enum
{
    TEE_TUI_HIDDEN_MODE = 0,
    TEE_TUI_CLEAR_MODE,
    TEE_TUI_TEMPORARY_CLEAR_MODE
} TEE_TUIEntryFieldMode;

typedef enum
{
    TEE_TUI_NUMERICAL = 0,
    TEE_TUI_ALPHANUMERICAL
} TEE_TUIEntryFieldType;

typedef enum
{
    TEE_TUI_PORTRAIT = 0,
    TEE_TUI_LANDSCAPE
} TEE_TUIScreenOrientation;

typedef enum
{
    TEE_TUI_NO_SOURCE = 0,
    TEE_TUI_REF_SOURCE,
    TEE_TUI_OBJECT_SOURCE
} TEE_TUIImageSource;

typedef struct
{
    TEE_TUIImageSource source;
    union
    {
        struct
        {
            void* image; //[inbuf]
            size_t imageLength;
        } ref;
        struct
        {
            uint32_t storageID;
            void* objectID; //[in(objectIDLength)]
            size_t objectIDLen;
        } object;
    };
    uint32_t width;
    uint32_t height;
} TEE_TUIImage;

typedef struct
{
    char *text;
    uint32_t textXOffset;
    uint32_t textYOffset;
    uint8_t textColor[3];
    TEE_TUIImage image;
    uint32_t imageXOffset;
    uint32_t imageYOffset;
} TEE_TUIScreenLabel;

typedef struct
{
    char* text;
    TEE_TUIImage image;
} TEE_TUIButton;

typedef struct
{
    TEE_TUIScreenOrientation screenOrientation;
    TEE_TUIScreenLabel label;
    TEE_TUIButton* buttons[TEE_TUI_NUMBER_BUTTON_TYPES];
    bool requestedButtons[TEE_TUI_NUMBER_BUTTON_TYPES];
} TEE_TUIScreenConfiguration;

typedef struct
{
    char* buttonText;
    uint32_t buttonWidth;
    uint32_t buttonHeight;
    bool buttonTextCustom;
    bool buttonImageCustom;
} TEE_TUIScreenButtonInfo;

typedef struct
{
    uint32_t grayscaleBitsDepth;
    uint32_t redBitsDepth;
    uint32_t greenBitsDepth;
    uint32_t blueBitsDepth;
    uint32_t widthInch;
    uint32_t heightInch;
    uint32_t maxEntryFields;
    uint32_t entryFieldLabelWidth;
    uint32_t entryFieldLabelHeight;
    uint32_t maxEntryFieldLength;
    uint8_t  labelColor[3];
    uint32_t labelWidth;
    uint32_t labelHeight;
    TEE_TUIScreenButtonInfo buttonInfo[TEE_TUI_NUMBER_BUTTON_TYPES];
} TEE_TUIScreenInfo;

typedef struct
{
    char* label;
    TEE_TUIEntryFieldMode mode;
    TEE_TUIEntryFieldType type;
    uint32_t minExpectedLength;
    uint32_t maxExpectedLength;
    char* buffer;        //[outstring]
    size_t bufferLength; //[outstring]
} TEE_TUIEntryField;


/////////////////////////////////////////////////////////
//    GP FUNCTIONS
/////////////////////////////////////////////////////////

TEE_Result TEE_TUICheckTextFormat(
    char* text,          // [in]
    uint32_t* width,     // [out]
    uint32_t* height,    // [out]
    uint32_t* lastIndex  // [out]
);

TEE_Result TEE_TUIGetScreenInfo(
    TEE_TUIScreenOrientation screenOrientation, // [in]
    uint32_t nbEntryFields,                     // [in]
    TEE_TUIScreenInfo* screenInfo               // [out]
);

TEE_Result TEE_TUIDisplayScreen(
    TEE_TUIScreenConfiguration* screenConfiguration, // [in]
    bool closeTUISession,                            // [in]
    TEE_TUIEntryField* entryFields,                  // [in]
    uint32_t entryFieldCount,                        // [in]
    TEE_TUIButtonType* selectedButton                // [out]
);

TEE_Result TEE_TUIInitSession(void);

TEE_Result TEE_TUICloseSession(void);




#endif //___TEE_TUI_API_H__

