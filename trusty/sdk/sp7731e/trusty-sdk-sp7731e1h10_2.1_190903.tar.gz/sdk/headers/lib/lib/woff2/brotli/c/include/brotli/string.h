#ifndef STRING_H
#define STRING_H
#include <stddef.h>
void *woff2_memcpy(void *dest, const void *src, size_t n);
void *woff2_memset(void *str, int c, size_t n);
#endif