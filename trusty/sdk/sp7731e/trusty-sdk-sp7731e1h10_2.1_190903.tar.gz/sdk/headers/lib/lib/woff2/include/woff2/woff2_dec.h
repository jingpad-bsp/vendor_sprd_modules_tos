#ifndef WOFF2_DEC_H
#define WOFF2_DEC_H

#include <woff2/tnet.h>
#include <woff2/buffer_c.h>
#include <woff2/variable_length.h>
#include <woff2/store_bytes.h>
#include <woff2/woff2_common.h>
#include <woff2/map_list.h>
#include <woff2/output.h>

typedef struct WOFF2Header {
  uint32_t flavor;
  uint32_t header_version;
  uint16_t num_tables;
  uint32_t compressed_offset;
  uint32_t compressed_length;
  uint32_t uncompressed_size;
  Table* tables;  // num_tables unique tables

}WOFF2Header;

/**
 * Accumulates data we may need to reconstruct a single font. One per font
 * created for a TTC.
 */
typedef struct WOFF2FontInfo {
  uint16_t num_glyphs;
  uint16_t index_format;
  uint16_t num_hmetrics;
  int16_t* x_mins;
  map_t* table_entry_by_tag;
}WOFF2FontInfo;

// Accumulates metadata as we rebuild the font
typedef struct RebuildMetadata {
  uint32_t header_checksum;  // set by WriteHeaders
  WOFF2FontInfo* font_infos;
  // checksums for tables that have been written.
  // (tag, src_offset) => checksum. Need both because 0-length loca.
  map_third_t* checksums;
}RebuildMetadata;

int WithSign(int flag, int baseval);

int TripletDecode(const uint8_t* flags_in, const uint8_t* in, size_t in_size,
    unsigned int n_points, Point* result, size_t* in_bytes_consumed);
	
int StorePoints(unsigned int n_points, const Point* points,
    unsigned int n_contours, unsigned int instruction_length,
    uint8_t* dst, size_t dst_size, size_t* glyph_size);

void ComputeBbox(unsigned int n_points, const Point* points, uint8_t* dst);

int SizeOfComposite(Buffer* composite_stream, size_t* size,
                     int* have_instructions);

int Pad4(WOFF2MemoryOut* out);

int StoreLoca(const uint32_t* loca_values, const uint16_t loca_values_size,  int index_format,
               uint32_t* checksum, WOFF2MemoryOut* out);
			   
// Reconstruct entire glyf table based on transformed original
int ReconstructGlyf(const uint8_t* data, Table* glyf_table,
                     uint32_t* glyf_checksum, Table * loca_table,
                     uint32_t* loca_checksum, WOFF2FontInfo* info,
                     WOFF2MemoryOut* out);
					 
Table* FindTable(Table* tables, uint16_t num_tables, uint32_t tag);

// Get numberOfHMetrics, https://www.microsoft.com/typography/otspec/hhea.htm
int ReadNumHMetrics(const uint8_t* data, size_t data_size,
                     uint16_t* num_hmetrics);
					 
// http://dev.w3.org/webfonts/WOFF2/spec/Overview.html#hmtx_table_format
int ReconstructTransformedHmtx(const uint8_t* transformed_buf,
                                size_t transformed_size,
                                uint16_t num_glyphs,
                                uint16_t num_hmetrics,
                                int16_t* x_mins,
                                uint32_t* checksum,
                                WOFF2MemoryOut* out);
								
int Woff2Uncompress(uint8_t* dst_buf, size_t dst_size,
  const uint8_t* src_buf, size_t src_size);

int ReadTableDirectory(Buffer* file, Table* tables,
    size_t num_tables);
	
// Writes a single Offset Table entry
size_t StoreOffsetTable(uint8_t* result, size_t offset, uint32_t flavor,
                        uint16_t num_tables);
						
size_t StoreTableEntry(uint8_t* result, uint32_t offset, uint32_t tag);

// First table goes after all the headers, table directory, etc
uint32_t ComputeOffsetToFirstTable(const WOFF2Header hdr);

// Offset tables assumed to have been written in with 0's initially.
// WOFF2Header isn't const so we can use [] instead of at() (which upsets FF)
int ReconstructFont(uint8_t* transformed_buf,
                     const uint32_t transformed_buf_size,
                     RebuildMetadata* metadata,
                     WOFF2Header* hdr,
                     size_t font_index,
                     WOFF2MemoryOut* out);
					 
int ReadWOFF2Header(const uint8_t* data, size_t length, WOFF2Header* hdr);

void TableSort(Table** tables, uint16_t num_tables);

// Write everything before the actual table data
int WriteHeaders(const uint8_t* data, size_t length, RebuildMetadata* metadata,
                  WOFF2Header* hdr, WOFF2MemoryOut* out);
				  
size_t ComputeWOFF2FinalSize(const uint8_t* data, size_t length);

int ConvertWOFF2ToTTF(void *result, size_t result_length,
                       const uint8_t *data, size_t length);
					   
#endif