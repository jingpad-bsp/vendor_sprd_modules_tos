#ifndef MAP_LIST_H
#define MAP_LIST_H

typedef struct Map {
	uint32_t tag;
	uint32_t src_offset;
}Map;

typedef struct map_t{
	Map map;
	struct map_t* map_next;
}map_t;

typedef struct SubStreams {
	const uint8_t* data;
	size_t substream_size;
}SubStreams;

typedef struct map_third_t {
	Map map;
	uint32_t checksum;
	struct map_third_t* map_third_next;
}map_third_t;

int MapThirdCheck(map_third_t* map_third_list, uint32_t tag);
int MapThirdGetSrcMap(map_third_t* map_third_list, uint32_t checksum, Map *map);
uint32_t MapThirdGetChecksum(map_third_t* map_third_list, Map map);
map_third_t* MapThirdPut(map_third_t* map_third_list, Map map, uint32_t checksum);
void MapThirdFree(map_third_t* map_third_list);

int MapCheck(map_t* map_list, uint32_t tag);
uint32_t MapGetSrcOffset(map_t* map_list, uint32_t tag);
uint32_t MapGetTag(map_t* map_list, uint32_t src_offset);
map_t* MapPut(map_t* map_list, Map map);
void MapFree(map_t* map_list);

#endif/* map_list.h */