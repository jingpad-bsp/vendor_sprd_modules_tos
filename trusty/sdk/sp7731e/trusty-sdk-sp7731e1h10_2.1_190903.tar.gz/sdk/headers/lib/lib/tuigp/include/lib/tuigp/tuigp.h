#pragma once

#include <interface/tui/tee_tui_api.h>


#ifndef NULL
#define NULL (void*)0
#endif
#ifndef false
#define false   (0)
#endif
#ifndef true
#define true   (1)
#endif


#define MAX_ENTRY_FILED_NUM     2
#define MAX_SECURE_IND_CNT     5


typedef enum {
    TUI_CHECK_TEXT_FORMAT = 0,
    TUI_GET_WINDOW_INFO,
    TUI_GET_GUI_STATE,
    TUI_WINDOW_STARTUP,
    TUI_WINDOW_CLOSE,
    // add new cmd here
    TUI_VECFONT_TA_CONNECT,
    TUI_VECFONT_DATA_TRANSMISSION,//transform vector font lib data
    TUI_CANCEL,
    TUI_DISP_CONF,
    TUI_STP_CONF,
    TUI_SET_SECURE_INDICATOR,//see reliance spec
    TUI_OPEN_DEMO_DLG, //just for test
    TUI_CMD_MAX
} tui_cmd;


typedef struct {
    char* text;          // [in]
    uint16_t textLen;
    uint32_t* width;     // [out]
    uint32_t* height;    // [out]
    uint32_t* lastIndex;  // [out]
} param_chkTxtForm;

typedef struct {
    uint32_t nbEntryFields;                     // [in]
    TEE_TUIScreenInfo screenInfo;               // [out]
} param_screenInfo;


typedef struct {
    TEE_TUIScreenConfiguration* screenConfiguration; // [in]
    uint16_t label_text_len;
    uint16_t btn_text_len[TEE_TUI_NUMBER_BUTTON_TYPES];
    bool closeTUISession;// [in]
    TEE_TUIEntryField* entryFields;                  // [in]
    uint16_t entryLabel_text_len[MAX_ENTRY_FILED_NUM];
    uint32_t entryFieldCount;                        // [in]
    uint8_t *secureIndicatorImage;// [in]
    uint32_t SIImageSize;// [in]
    TEE_TUIButtonType* selectedButton;                // [out]
} param_screenDispReq;


typedef struct {
    TEE_TUIImageSource source;
    uint32_t width;
    uint32_t height;
    uint32_t imageID;
    uint32_t imageLength;
    void* image;
} param_tuiImageReq;

typedef struct
{
    char* text;
    uint16_t text_len;
    param_tuiImageReq image;
} param_tuiBtnReq;

typedef struct
{
    char* label;
    uint16_t label_text_len;
    TEE_TUIEntryFieldMode mode;
    TEE_TUIEntryFieldType type;
    uint32_t minExpectedLength;
    uint32_t maxExpectedLength;
    char* buffer;        //[outstring]
    uint32_t bufferLength;
}param_tuiEntryFieldReq;


typedef struct {
    //screen conf [in]
    TEE_TUIScreenOrientation screenOrientation;
    ////label
    char* labelText;
    uint16_t label_text_len;
    uint32_t labelTextXOffset;
    uint32_t labelTextYOffset;
    uint8_t labelTextColor[3];
    param_tuiImageReq labelImage;
    uint32_t labelImageXOffset;
    uint32_t labelImageYOffset;
    ////button
    param_tuiBtnReq* buttons[TEE_TUI_NUMBER_BUTTON_TYPES];
    bool requestedButtons[TEE_TUI_NUMBER_BUTTON_TYPES];
    // entry
    param_tuiEntryFieldReq* entryFields[MAX_ENTRY_FILED_NUM];                  // [in]
    uint32_t entryFieldCount;                        // [in]
    // si
    uint8_t* secureIndicatorImage;// [in]
    uint32_t SIImageSize;// [in]
    //others
    bool closeTUISession;// [in]
    TEE_TUIButtonType* selectedButton;                // [out]
} param_screenDispReq_new;

///////////////////////////////////////////
//
//    FOR NATIVE TUI FUNCTIONS INTERFACES
//
///////////////////////////////////////////
typedef struct {
    char* label;
    TEE_TUIImage *siBmp[MAX_SECURE_IND_CNT]; // [in]
    char *description[MAX_SECURE_IND_CNT]; // [in]
    uint16_t descriptionLen[MAX_SECURE_IND_CNT]; // [in]
    uint16_t siCnt; // [in]
    uint32_t *selected; // [out]
} param_SI_settings;



/**
** this function TEE_Result TEE_TUISetSecureIndcator startup a window for user to select a secure indicator.
**Parameters
**    image: images data of SI to display. Only .BMP supported so far.
**    imagesCnt: count of SI images
**    selected: index of SI image that user selects
**Return Value
**    TEE_SUCCESS: In case of success.
**    TEE_ERROR_GENERAL: general errors occur
**/
TEE_Result TEE_TUISetSecureIndcator(
    param_SI_settings* settings    // [int]
);


TEE_Result TEE_TUIGetSecureIndcator(
    uint8_t* image,    //[OUT]
    uint32_t* imagesize    //[OUT]
);

