#ifndef SELIB_UTIL_H_
#define SELIB_UTIL_H_


#include <stdlib.h>
#include <trusty_std.h>



#define MEMORY_DEBUG
#define ASSERT_DEBUG


void* TEE_Malloc_Debug(uint32_t ,const char* , int);
void TEE_Free_Debug(void* ,const char*, int );
void* TEE_Malloc(uint32_t);
void TEE_Free(void*);



#ifdef MEMORY_DEBUG
#define malloc(n)       TEE_Malloc_Debug(n,__FILE__,__LINE__)
#define free(p)         TEE_Free_Debug(p,__FILE__,__LINE__)
#else
#define malloc(n)       TEE_Malloc(n)
#define free(p)         TEE_Free(p)
#endif



#ifdef ASSERT_DEBUG
#define DEBUG_ASSERT(x) \
    do {                                                                                               \
      if (unlikely(!(x))) {                                                                           \
        fprintf(stderr, "%s FATAL ERROR: ASSERT at (%s:%d): %s \n", SE_LOG_TAG,__FILE__, __LINE__, #x);\
        nanosleep(0, 0, 2000 * 1000000UL);                                                             \
        abort();                                                                                       \
      }                                                                                                \
    } while (0)/*when error  occur, print log and exit ta*/
#else
#define DEBUG_ASSERT(x) \
    do { } while(0)
#endif


void list_memory(void);




#endif

