#ifndef SELIB_IPC_H_
#define SELIB_IPC_H_

#include <interface/se/se.h>



typedef handle_t se_session_t;


long send_req(se_session_t session, struct se_msg *msg,uint32_t msg_size,uint8_t *out, uint32_t *out_size);



#endif

