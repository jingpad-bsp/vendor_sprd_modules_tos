#ifndef __png_H_
#define __png_H_

#define PNG_IDAT           0x49444154
#define PNG_IEDL           0x49454e44
#define PNG_MAGNIFICATION  2048
#define PNG_IDAT_MAXNUM    10

#define png_fourcc_code(a, b, c, d) ((uint32_t)(a) | ((uint32_t)(b) << 8) | \
                 ((uint32_t)(c) << 16) | ((uint32_t)(d) << 24))

/* [15:0] R:G:B 5:6:5 little endian */
#define PNG_DRM_FORMAT_RGB565        png_fourcc_code('R', 'G', '1', '6')


typedef struct tagPNGDATAHEADER {
    uint32_t dsize;
    uint32_t dtype;
} __attribute__((packed)) PNGDATAHEADER;

typedef struct tagPNGIHDRINFOHEADER {
    uint32_t width;
    uint32_t height;

    uint8_t  bitdepht;
    uint8_t  colortype;
    uint8_t  Compressionmth;
    uint8_t  filtermth;
    uint8_t  interlace;
} __attribute__((packed)) PNGUHDRINFOHEADER;

typedef enum {
    PNG_INVERSEFILTER_NONE = 0,
    PNG_INVERSEFILTER_SUB,
    PNG_INVERSEFILTER_UP,
    PNG_INVERSEFILTER_AVERAGE,
    PNG_INVERSEFILTER_PAETH,
} png_inversefilter_t;

typedef enum {
    PNG_COLOR_TYPE_GLAY = 0,
    PNG_COLOR_TYPE_RGB = 2,
    PNG_COLOR_TYPE_RGBA = 6,
} PNG_COLOR_TYPE;

typedef enum {
    PNG_SUCCESS = 0,
    PNG_MEM_PNG_DATA_ERR,
    PNG_NO_IDAT_ERR,
    PNG_DATA_NULL_ERR,
    PNG_WRONG_IMAGETYPE_ERR,
    PNG_WRONG_PIXNUM_ERR,
    PNG_NO_INVERSEFILTER_ERR,
    PNG_MEM_UNCOMPRESS_DATA_ERR,
    PNG_IMAGE_TYPE_ERR,
    PNG_IDAT_DATA_ERR,
    PNG_MEM_COMPR_DATA_ERR,
    PNG_READ_INIT_ERR,
} png_ERROR_MSG;

typedef enum {
    PIX_BYTE_RGB565 = 2,
    PIX_BYTE_RGBA = 4
} PIX_BYTE_TYPE;

typedef enum {
    PNG_GRAY_PIXNUM = 1,
    PNG_RGB_PIXNUM = 3,
    PNG_RGBA_PIXNUM = 4,
} PNG_TYPE_PIXNUM;

typedef struct png_info_struct {
    uint8_t  pixnum;
    uint8_t  colortype;
    uint16_t width;
    uint16_t height;

    unsigned long idat_length;
    unsigned long uncompr_length;
    uint32_t inflate_length;

    uint8_t*  uncompr_data;
} __attribute__((packed)) png_info_t;

uint8_t png_check_imagetype(uint8_t* png);

uint8_t png_get_size(uint8_t* png, uint32_t* w, uint32_t* h);

uint32_t png_swap_num(uint32_t num);

uint8_t png_read_image_default(uint8_t* png, uint32_t* png_data);

uint8_t png_read_image_zoom(uint8_t* png, uint32_t* png_zoom_data,
                            uint16_t png_zoom_width, uint16_t png_zoom_height);

uint8_t png_read_image_complete(uint8_t* png, void* dAddr, uint16_t png_zoom_width,
                                uint16_t png_zoom_height, uint32_t bpp, uint32_t pixformat);

uint16_t png_argb2rgb565(uint32_t argb);

uint32_t png_rgba2argb(uint32_t rgba);

uint32_t png_rgb2argb(uint32_t rgba);

uint32_t png_glay2argb(uint8_t glay);

int16_t png_abs(int16_t number);
#endif
