/* Copyright 2018 SPRD Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* DATA SWAP INET */
#ifndef T_NET_H_
#define T_NET_H_
int checkCPUendian(void);
unsigned long int t_ntohl(unsigned long int n);
unsigned short int t_ntohs(unsigned short int n);

#endif